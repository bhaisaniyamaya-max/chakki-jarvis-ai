from flask import Flask, request, redirect, url_for, render_template_string, flash
import sqlite3, re, os, csv, io
from datetime import datetime
from urllib.parse import quote

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "chakki_jarvis_data.db")
app = Flask(__name__)
app.secret_key = "change-this-local-key"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS rates(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item TEXT UNIQUE NOT NULL,
            rate REAL NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            kind TEXT NOT NULL,
            item TEXT DEFAULT '',
            kg REAL DEFAULT 0,
            rate REAL DEFAULT 0,
            amount REAL NOT NULL,
            note TEXT DEFAULT '',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        );
        """)
        for item in ["गेहूँ का आटा", "बाटी", "मक्का", "चना", "मसाला"]:
            c.execute("INSERT OR IGNORE INTO rates(item,rate) VALUES(?,0)", (item,))

def money(x):
    return f"₹{float(x):,.2f}"

app.jinja_env.filters["rupee"] = money
app.jinja_env.filters["digits"] = lambda x: re.sub(r"\\D", "", x or "")

def totals(cid):
    with db() as c:
        row = c.execute("""SELECT
          COALESCE(SUM(CASE WHEN kind='charge' THEN amount ELSE 0 END),0) AS charges,
          COALESCE(SUM(CASE WHEN kind='payment' THEN amount ELSE 0 END),0) AS paid
          FROM entries WHERE customer_id=?""", (cid,)).fetchone()
    return float(row["charges"]), float(row["paid"]), float(row["charges"]-row["paid"])

def find_customer(text):
    s = text.strip().lower()
    with db() as c:
        rows = c.execute("SELECT * FROM customers ORDER BY name").fetchall()
    for r in rows:
        if r["name"].lower() in s:
            return r
    return None

def number_words(s):
    words = {
        "शून्य":0,"एक":1,"दो":2,"तीन":3,"चार":4,"पांच":5,"पाँच":5,"छह":6,"छः":6,
        "सात":7,"आठ":8,"नौ":9,"दस":10,"ग्यारह":11,"बारह":12,"तेरह":13,"चौदह":14,
        "पंद्रह":15,"सोलह":16,"सत्रह":17,"अठारह":18,"उन्नीस":19,"बीस":20,
        "इक्कीस":21,"बाईस":22,"तेईस":23,"चौबीस":24,"पच्चीस":25,"तीस":30,
        "चालीस":40,"पचास":50,"साठ":60,"सत्तर":70,"अस्सी":80,"नब्बे":90,
        "सौ":100,"डेढ़":1.5,"आधा":0.5
    }
    for w,n in sorted(words.items(), key=lambda x: -len(x[0])):
        s = s.replace(w, str(n))
    trans = str.maketrans("०१२३४५६७८९", "0123456789")
    return s.translate(trans)

def parse_numbers(s):
    s = number_words(s)
    return [float(x) for x in re.findall(r'\d+(?:\.\d+)?', s)]

def get_rate(item):
    with db() as c:
        row = c.execute("SELECT rate FROM rates WHERE item=?", (item,)).fetchone()
    return float(row["rate"]) if row else 0.0

def detect_item(s):
    options = [
        ("गेहूँ का आटा", ["गेहूं","गेहूँ","आटा","गेहूं का आटा","गेहूँ का आटा"]),
        ("बाटी", ["बाटी","बाफला"]),
        ("मक्का", ["मक्का","मक्के"]),
        ("चना", ["चना","बेसन"]),
        ("मसाला", ["मसाला","मसाले"])
    ]
    for item, words in options:
        if any(w in s for w in words):
            return item
    return "अन्य"

def voice_action(text):
    s = text.strip()
    low = s.lower()
    if not s:
        return "कुछ सुनाई नहीं दिया। फिर से बोलिए।"
    if any(x in s for x in ["मदद","क्या बोलूं","कमांड"]):
        return "आप बोल सकते हैं: रमेश का खाता खोलो; रमेश के 20 किलो गेहूँ 30 रुपये लिखो; रमेश ने 500 रुपये जमा किए; गेहूँ का रेट 35 रुपये करो।"
    if any(x in s for x in ["रेट"]) and any(x in s for x in ["करो","रखो","बदल"]):
        item = detect_item(s)
        nums = parse_numbers(s)
        if nums:
            rate = nums[-1]
            with db() as c:
                c.execute("INSERT INTO rates(item,rate) VALUES(?,?) ON CONFLICT(item) DO UPDATE SET rate=excluded.rate", (item,rate))
            return f"{item} का नया रेट {money(rate)} प्रति किलो सेव कर दिया।"
        return "रेट बताइए। जैसे गेहूँ का रेट 35 रुपये करो।"
    cust = find_customer(s)
    if any(x in s for x in ["खाता","हिसाब","बाकी"]) and not cust:
        return "ग्राहक का नाम नहीं मिला। पहले ग्राहक जोड़िए या नाम साफ बोलिए।"
    if cust and any(x in s for x in ["खाता","हिसाब","बाकी"]):
        ch, paid, bal = totals(cust["id"])
        return f"{cust['name']} का कुल हिसाब {money(ch)}, जमा {money(paid)}, बाकी {money(bal)} है।"
    if cust and any(x in s for x in ["जमा","भुगतान","दिए","दिया","पेमेंट"]):
        nums = parse_numbers(s)
        if nums:
            amount = nums[-1]
            with db() as c:
                c.execute("INSERT INTO entries(customer_id,kind,amount,note) VALUES(?,?,?,?)",
                          (cust["id"],"payment",amount,"आवाज से जमा"))
            return f"{cust['name']} के खाते में {money(amount)} जमा कर दिया।"
        return "कितने रुपये जमा हुए?"
    if cust and any(x in s for x in ["किलो","किलो का","पीसा","पिसाई","लिखो","डालो"]):
        nums = parse_numbers(s)
        if len(nums) >= 1:
            kg = nums[0]
            item = detect_item(s)
            rate = nums[1] if len(nums) >= 2 else get_rate(item)
            if rate <= 0:
                return f"{item} का रेट सेट नहीं है। पहले बोलिए: {item} का रेट 30 रुपये करो।"
            amount = kg * rate
            with db() as c:
                c.execute("INSERT INTO entries(customer_id,kind,item,kg,rate,amount,note) VALUES(?,?,?,?,?,?,?)",
                          (cust["id"],"charge",item,kg,rate,amount,"आवाज से पिसाई"))
            return f"{cust['name']} के खाते में {kg:g} किलो {item}, {money(rate)} प्रति किलो के हिसाब से {money(amount)} जोड़ दिया।"
        return "कितने किलो और क्या रेट है?"
    if any(x in s for x in ["रिमाइंडर","याद दिला","बाकीदार"]):
        return "रिमाइंडर पेज खोल रहा हूँ। वहाँ WhatsApp या SMS दबाकर आप खुद भेज सकते हैं।"
    return "यह बात समझ नहीं आई। मदद बोलिए, या ग्राहक का नाम, किलो और रेट बताइए।"

PAGE = r"""
<!doctype html><html lang="hi"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CHAKKI JARVIS AI</title>
<style>
body{font-family:Arial,sans-serif;background:#f3f5f7;margin:0;color:#17202a}
header{background:#173b57;color:white;padding:16px;text-align:center}
main{max-width:850px;margin:auto;padding:12px}
.card{background:white;border-radius:12px;padding:14px;margin:12px 0;box-shadow:0 1px 5px #ccd}
input,button,select{font-size:16px;padding:11px;margin:4px;border-radius:8px;border:1px solid #bbb}
button{background:#176b87;color:white;border:0}
a{color:#075b8c} .muted{color:#667}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px}
.big{font-size:19px;font-weight:bold}
</style>
<header><h2>🛠️ CHAKKI JARVIS AI</h2><div>बोलकर हिसाब • ऑटो गणना • ग्राहक खाता</div></header>
<main>
{% with msgs=get_flashed_messages() %}{% for m in msgs %}<div class="card">{{m}}</div>{% endfor %}{% endwith %}
<div class="card">
 <div class="big">🎙️ Jarvis से बोलिए</div>
 <button onclick="startVoice()">🎤 बोलकर आदेश दें</button>
 <button onclick="speak('नमस्ते, मैं चक्की जार्विस हूँ। मदद बोलकर कमांड जानिए।')">🔊 आवाज़ जाँचें</button>
 <form id="voiceForm" method="post" action="/voice"><input id="command" name="command" style="width:90%" placeholder="या यहाँ लिखें: रमेश का खाता खोलो"><button>भेजें</button></form>
 <p id="heard" class="muted">माइक दबाकर हिंदी में बोलें। Chrome में माइक्रोफोन अनुमति दें।</p>
 {% if answer %}<p class="big">Jarvis: {{answer}}</p><script>window.addEventListener('load',()=>speak({{answer|tojson}}));</script>{% endif %}
</div>
<div class="grid">
<div class="card"><h3>➕ ग्राहक जोड़ें</h3><form method="post" action="/add_customer"><input name="name" placeholder="ग्राहक का नाम" required><input name="phone" placeholder="मोबाइल नंबर"><button>जोड़ें</button></form></div>
<div class="card"><h3>📥 VCF संपर्क इम्पोर्ट</h3><form method="post" action="/import_vcf" enctype="multipart/form-data"><input type="file" name="vcf" accept=".vcf,text/vcard" required><button>संपर्क जोड़ें</button></form><small>फोन Contacts से Export की हुई .vcf फाइल चुनें।</small></div>
<div class="card"><h3>⚖️ सामान का रेट</h3><form method="post" action="/set_rate"><select name="item">{% for r in rates %}<option>{{r.item}}</option>{% endfor %}<option>अन्य</option></select><input name="rate" type="number" step="0.01" placeholder="₹ प्रति किलो" required><button>रेट सेव</button></form>{% for r in rates %}<div>{{r.item}} — {{r.rate}} रुपये/किलो</div>{% endfor %}</div>
<div class="card"><h3>🔔 बाकी और रिमाइंडर</h3><a href="/reminders">बाकीदारों की सूची खोलें</a></div>
</div>
<div class="card"><h3>👥 ग्राहक खाते</h3>
{% for c in customers %}
<div style="border-top:1px solid #ddd;padding:10px 0">
 <b>{{c.name}}</b> — {{c.phone or 'नंबर नहीं'}}
 <div>कुल {{c.charges|rupee}} | जमा {{c.paid|rupee}} | <b>बाकी {{c.balance|rupee}}</b></div>
 <a href="/customer/{{c.id}}">खाता खोलें</a>
 {% if c.phone %} | <a href="tel:{{c.phone}}">कॉल</a> | <a href="https://wa.me/{{c.phone|digits}}" target="_blank">WhatsApp</a> | <a href="sms:{{c.phone}}">SMS</a>{% endif %}
</div>{% else %}<p>अभी ग्राहक नहीं हैं।</p>{% endfor %}
</div>
</main>
<script>
function speak(t){if(!('speechSynthesis' in window))return; speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(t);u.lang='hi-IN';speechSynthesis.speak(u);}
function startVoice(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){document.getElementById('heard').innerText='इस ब्राउज़र में आवाज़ पहचान उपलब्ध नहीं। Chrome में खोलें या टेक्स्ट लिखें।';return;}
 let r=new SR();r.lang='hi-IN';r.interimResults=false;r.maxAlternatives=1;
 document.getElementById('heard').innerText='सुन रहा हूँ...';
 r.onresult=e=>{let t=e.results[0][0].transcript;document.getElementById('command').value=t;document.getElementById('heard').innerText='सुना: '+t;document.getElementById('voiceForm').requestSubmit();};
 r.onerror=e=>document.getElementById('heard').innerText='माइक/इंटरनेट की समस्या: '+e.error;
 r.start();
}
</script></html>
"""

def render(answer=None):
    with db() as c:
        rates = c.execute("SELECT * FROM rates ORDER BY item").fetchall()
        rows = c.execute("SELECT * FROM customers ORDER BY name").fetchall()
    customers=[]
    for r in rows:
        ch,paid,bal=totals(r["id"])
        customers.append(dict(id=r["id"],name=r["name"],phone=r["phone"],charges=ch,paid=paid,balance=bal))
    return render_template_string(PAGE, customers=customers, rates=rates, answer=answer,
        rupee=money, digits=lambda x: re.sub(r'\D','',x or ''))

@app.route("/")
def home(): return render()

@app.route("/voice", methods=["POST"])
def voice():
    answer=voice_action(request.form.get("command",""))
    if "रिमाइंडर पेज" in answer: return redirect(url_for("reminders"))
    return render(answer)

@app.route("/add_customer", methods=["POST"])
def add_customer():
    name=request.form.get("name","").strip(); phone=request.form.get("phone","").strip()
    if name:
        with db() as c: c.execute("INSERT INTO customers(name,phone) VALUES(?,?)",(name,phone))
        flash("ग्राहक जोड़ दिया गया।")
    return redirect(url_for("home"))

@app.route("/set_rate", methods=["POST"])
def set_rate():
    item=request.form.get("item","अन्य").strip()
    try: rate=float(request.form.get("rate","0"))
    except: rate=0
    with db() as c:
        c.execute("INSERT INTO rates(item,rate) VALUES(?,?) ON CONFLICT(item) DO UPDATE SET rate=excluded.rate",(item,rate))
    flash(f"{item} का रेट सेव हो गया।")
    return redirect(url_for("home"))

@app.route("/customer/<int:cid>")
def customer(cid):
    with db() as c:
        cust=c.execute("SELECT * FROM customers WHERE id=?",(cid,)).fetchone()
        entries=c.execute("SELECT * FROM entries WHERE customer_id=? ORDER BY id DESC",(cid,)).fetchall()
    if not cust: return "ग्राहक नहीं मिला",404
    ch,paid,bal=totals(cid)
    return render_template_string("""<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><h2>{{c.name}} का खाता</h2>
    <p>कुल {{ch|rupee}} | जमा {{paid|rupee}} | बाकी {{bal|rupee}}</p>
    <form method=post action="/manual_entry/{{c.id}}"><select name=kind><option value=charge>पिसाई जोड़ें</option><option value=payment>जमा</option></select>
    <input name=item placeholder="सामान"><input name=kg type=number step=.01 placeholder="किलो"><input name=rate type=number step=.01 placeholder="रेट/रुपये"><button>सेव</button></form>
    {% for e in entries %}<p>{{e.created_at}} — {{e.item}} {{e.kg}}kg — {{e.amount|rupee}} ({{e.kind}})</p>{% endfor %}
    <p><a href="/">वापस</a></p>""",c=c,entries=entries,ch=ch,paid=paid,bal=bal,rupee=money)

@app.route("/manual_entry/<int:cid>",methods=["POST"])
def manual_entry(cid):
    kind=request.form.get("kind")
    try:
        if kind=="payment":
            amount=float(request.form.get("rate") or request.form.get("kg") or 0)
            with db() as c:c.execute("INSERT INTO entries(customer_id,kind,amount,note) VALUES(?,?,?,?)",(cid,"payment",amount,"जमा"))
        else:
            kg=float(request.form.get("kg") or 0); rate=float(request.form.get("rate") or 0)
            with db() as c:c.execute("INSERT INTO entries(customer_id,kind,item,kg,rate,amount) VALUES(?,?,?,?,?,?)",(cid,"charge",request.form.get("item",""),kg,rate,kg*rate))
    except: flash("रकम सही भरें।")
    return redirect(url_for("customer",cid=cid))

@app.route("/reminders")
def reminders():
    with db() as c: rows=c.execute("SELECT * FROM customers ORDER BY name").fetchall()
    out=[]
    for r in rows:
        ch,paid,bal=totals(r["id"])
        if bal>0 and r["phone"]:
            msg=quote(f"नमस्ते {r['name']}, चक्की का आपका बाकी हिसाब {money(bal)} है। कृपया भुगतान कर दें।")
            phone=re.sub(r'\D','',r["phone"])
            out.append((r["name"],phone,bal,msg))
    return render_template_string("""<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><h2>बाकीदारों के रिमाइंडर</h2>
    <p>यहाँ से आप खुद WhatsApp/SMS खोलकर संदेश भेजें। अपने-आप कोई संदेश नहीं भेजा जाता।</p>
    {% for n,p,b,m in rows %}<p><b>{{n}}</b> — बाकी {{b|rupee}}<br><a href="https://wa.me/{{p}}?text={{m}}" target=_blank>WhatsApp खोलें</a> | <a href="sms:{{p}}?body={{m}}">SMS खोलें</a></p>{% endfor %}
    <a href="/">वापस</a>""",rows=out,rupee=money)

@app.route("/import_vcf",methods=["POST"])
def import_vcf():
    f=request.files.get("vcf")
    if not f: flash("VCF फाइल चुनें।"); return redirect(url_for("home"))
    data=f.read().decode("utf-8","ignore")
    cards=re.split(r"BEGIN:VCARD",data,flags=re.I)
    count=0
    for card in cards:
        nm=re.search(r"FN(?:;[^:]*)?:(.*)",card,re.I)
        tel=re.search(r"TEL(?:;[^:]*)?:(.*)",card,re.I)
        if nm:
            name=nm.group(1).strip()
            phone=tel.group(1).strip() if tel else ""
            if name:
                with db() as c:
                    exists=c.execute("SELECT id FROM customers WHERE name=? AND phone=?",(name,phone)).fetchone()
                    if not exists:c.execute("INSERT INTO customers(name,phone) VALUES(?,?)",(name,phone));count+=1
    flash(f"{count} संपर्क जोड़े गए।")
    return redirect(url_for("home"))

if __name__ == "__main__":
    init_db()
    print("CHAKKI JARVIS AI: http://127.0.0.1:5002")
    app.run(host="127.0.0.1",port=5002,debug=False)
